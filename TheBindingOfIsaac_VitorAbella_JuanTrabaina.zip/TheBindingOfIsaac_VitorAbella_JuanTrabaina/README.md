# The Binding of Isaac

Windows:

Executar TheBindingOfIsaac_Windows.exe

Ubuntu:

Executar TheBindingOfIsaac_Ubuntu


